# GreenSprout Hydroseeding Website · Phase 3

The responsive GreenSprout homepage, global navigation and footer, built with
Next.js App Router, TypeScript and Tailwind CSS.

## Requirements

- Node.js 22 LTS
- npm 10 or newer
- Visual Studio Code (recommended)
- Git (recommended)

## Start locally

```powershell
npm ci
npm run dev
```

Open http://localhost:3000.

## Useful commands

```powershell
npm run dev
npm run lint
npm run build
npm start
```

## Phase 3 includes

- Manrope typography through `next/font`
- GreenSprout colour and spacing tokens
- Reusable split-arrow button component
- Lucide icon system
- Desktop mega navigation and a 77vw mobile drawer
- Ten-section editorial homepage
- Full responsive footer
- Three-slide homepage hero
- Automatic and manually controlled services carousel
- All photography stored locally in `public/images`
- Seven-step project process
- Embla-powered two-card services carousel
- Complete About page
- Complete Contact page with call, WhatsApp, email and enquiry form options
- Clearer hydroseeding, erosion-control and landscape-establishment explanations
- Image-led mega menus with visible service actions
- Services overview page and six dedicated service pages
- Detailed Hydroseeding education and conversion journey
- React Select enquiry field and branded WhatsApp navigation action
- Image-led About values cards with hover descriptions
- Direct local-image delivery for easier replacements
- Image-led process, industry, capability and knowledge cards
- Official enquiry contacts: 0700 355 113 and info@greensprout.com
- Breakpoints for wide and small laptops, tablets, phones and compact phones
- Keyboard focus and reduced-motion support

## Before launch

Replace the empty social, article and project links before launch.

## Brand assets

The current full GreenSprout logo is stored in `public/brand`. A simplified
horizontal or white navbar mark may be added later if the full emblem becomes
too detailed at navigation size.

## Replacing photographs

Every website photograph is stored in `public/images`. Keep the existing
filename when replacing a photo and the website will use the new image without
requiring a component change.

Local images are delivered without Next.js optimisation so a replaced file is
not held by the framework image cache. Use Ctrl+F5 if the browser still shows a
previous copy.

## Temporary image credits

The first design pass uses replaceable photographs from Unsplash:

- David Clode — Lewa Wildlife Conservancy, Isiolo, Kenya
- Irewolede — Limuru, Kenya
- Konstantinos Papadopoulos — seedlings
- Toffi Teraytay — fieldwork

These may be replaced with GreenSprout project photography without changing
the page structure.
