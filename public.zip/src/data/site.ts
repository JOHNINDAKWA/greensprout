export type NavChild = { title: string; description: string; href: string };
export type NavItem = { label: string; href: string; children?: NavChild[] };

export const navigation: NavItem[] = [
  { label: "Solutions", href: "/#solutions", children: [
    { title: "Hydroseeding", description: "A modern, even way to plant grass on lawns, large areas and slopes.", href: "/services/hydroseeding" },
    { title: "Erosion control", description: "Protect exposed soil and slopes from damage caused by rain and runoff.", href: "/services/erosion-control" },
    { title: "Land rehabilitation", description: "Bring grass and other vegetation back to bare or damaged land.", href: "/services/land-rehabilitation" },
    { title: "Landscape establishment", description: "Plan, prepare and grow healthy green spaces that are easier to maintain.", href: "/services/landscape-establishment" },
  ]},
  { label: "Consulting", href: "/#consulting", children: [
    { title: "Consultation", description: "Talk to us about your land, the problem and the result you need.", href: "/#consulting" },
    { title: "Site assessment", description: "We inspect the soil, slope, drainage, access and size of the area.", href: "/#consulting" },
    { title: "Consulting packages", description: "Choose Bronze, Silver or Gold support depending on your project.", href: "/#consulting" },
    { title: "Project coordination", description: "We help manage the work, suppliers, inspections and handover.", href: "/#process" },
  ]},
  { label: "Industries", href: "/industries", children: [
    { title: "Property & hospitality", description: "Estates, resorts, schools and commercial landscapes.", href: "/industries/property-hospitality" },
    { title: "Infrastructure", description: "Roads, embankments and large-scale development sites.", href: "/industries/infrastructure" },
    { title: "Public sector", description: "Counties, institutions and community land programmes.", href: "/industries/public-sector" },
    { title: "Agriculture & conservation", description: "Soil protection, revegetation and resilient land use.", href: "/industries/agriculture-conservation" },
  ]},
  { label: "Projects", href: "/#projects" },
  { label: "Knowledge", href: "/#knowledge" },
  { label: "About", href: "/about" },
];

export const footerGroups = [
  { title: "What we do", links: ["Hydroseeding", "Erosion control", "Landscape establishment", "Land rehabilitation"] },
  { title: "Consulting", links: ["Consultation", "Site assessment", "Bronze package", "Silver package", "Gold package"] },
  { title: "Explore", links: ["Industries", "Projects", "Knowledge centre", "About GreenSprout", "Contact"] },
];
