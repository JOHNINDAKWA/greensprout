import { pageMetadata } from "@/lib/seo";
import type { Metadata } from "next";
import Link from "next/link";
import { ArrowRight } from "lucide-react";

import { QuoteForm } from "@/components/quote/quote-form";
import { SiteHeader } from "@/components/layout/site-header";
import { SiteFooter } from "@/components/layout/site-footer";

export const metadata: Metadata = pageMetadata({ title: "Get a quote", description: "Request a site-based quotation for lawn care, natural sod installation or consulting. Ask about future specialist services in Kenya.", path: "/quote" });

export default async function QuotePage({ searchParams }: { searchParams: Promise<{ service?: string; method?: string }> }) {
  const { service = "not-sure", method } = await searchParams;
  return <><SiteHeader/><main>
    <section className="p5-quote-content page-shell"><div className="p5-quote-side"><p className="eyebrow">A clear way forward</p><h2>What happens after you get in touch?</h2><ol><li><span>01</span><div><h3>We review your site details</h3><p>We may ask for photographs, a plan or a quick follow-up call.</p></div></li><li><span>02</span><div><h3>We recommend the right service</h3><p>That may be a paid consultation, a site assessment, a consulting package or a project quotation.</p></div></li><li><span>03</span><div><h3>You approve the scope and fee</h3><p>We explain what is included, what costs extra and how payment for a paid appointment will be arranged before booking.</p></div></li></ol><div className="p5-quote-note"><strong>Know the starting point before booking.</strong><p>A 30–45 minute consultation is KSh 5,000. On-site consultations start at KSh 15,000 and detailed site surveys at KSh 25,000. The final scope, travel and any laboratory charges are confirmed separately. No payment is taken on this page.</p><Link href="/consulting#individual-services">See consulting options and rates <ArrowRight size={17}/></Link></div></div><QuoteForm key={`${service}-${method ?? "help"}`} initialService={service} initialMethod={method}/></section>

    <section className="p5-quote-other"><div className="page-shell"><p>Prefer a direct conversation?</p><h2>We’re easy to reach.</h2><div><Link href="tel:+254700355113">Call 0700 355 113 <ArrowRight size={18}/></Link><Link href="https://wa.me/254700355113">Chat on WhatsApp <ArrowRight size={18}/></Link><Link href="mailto:info@greensprout.com">Email GreenSprout <ArrowRight size={18}/></Link></div></div></section>
  </main><SiteFooter/></>;
}
